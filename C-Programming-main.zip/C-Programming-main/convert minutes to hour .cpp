#include <iostream>
using namespace std;
int main() {
    int m;
    cout << "Enter minutes: ";
    cin >> m;
    cout << "Hours = " << m / 60;
    return 0;
}