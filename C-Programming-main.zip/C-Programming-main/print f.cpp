#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    printf("hi");
    return 0;
}