#include <iostream>
using namespace std;
int main() {
    float a, b;
    cout << "Enter two numbers: ";
    cin >> a >> b;
    cout << "Division = " << a / b;
    return 0;
}