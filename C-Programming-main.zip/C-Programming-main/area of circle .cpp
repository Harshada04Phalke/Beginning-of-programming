#include <iostream>
using namespace std;
int main() {
    float r;
    cout << "Enter radius: ";
    cin >> r;
    cout << "Area = " << 3.14159 * r * r;
    return 0;
}