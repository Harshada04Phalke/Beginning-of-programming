#include <iostream>
using namespace std;
int main() {
    float l, w;
    cout << "Enter length and width: ";
    cin >> l >> w;
    cout << "Area = " << l * w;
    return 0;
}