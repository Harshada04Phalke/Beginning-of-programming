#include <stdio.h>
int main() {
    float r;
    printf("Enter radius: ");
    scanf("%f", &r);
    printf("Area = %.2f\n", 3.14 * r * r);
    return 0;
}