#include <iostream>
using namespace std;
int main() {
    int h;
    cout << "Enter hours: ";
    cin >> h;
    cout << "Minutes = " << h * 60;
    return 0;
}