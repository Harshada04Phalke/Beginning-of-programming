#include <iostream>
#include <cmath>
using namespace std;
int main() {
    int a, b;
    cout << "Enter base and exponent: ";
    cin >> a >> b;
    cout << "Result = " << pow(a, b);
    return 0;
}