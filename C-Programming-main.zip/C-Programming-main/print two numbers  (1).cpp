#include <stdio.h>
int main() {
    int a = 5, b = 10;
    printf("First number: %d\n", a);
    printf("Second number: %d\n", b);
    return 0;
}