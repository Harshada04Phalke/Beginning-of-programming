#include <iostream>
#include <cmath>
using namespace std;
int main() {
    float n;
    cout << "Enter a number: ";
    cin >> n;
    cout << "Square root = " << sqrt(n);
    return 0;
}