#include <stdio.h>
int main() {
    for(int i=1; i<=20; i+=2)
        printf("%d ", i);
    return 0;
}