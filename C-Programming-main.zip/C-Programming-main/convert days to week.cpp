#include <iostream>
using namespace std;
int main() {
    int days;
    cout << "Enter days: ";
    cin >> days;
    cout << "Weeks = " << days / 7;
    return 0;
}