// save as hi.cpp
#include <iostream>

int main() {
    std::cout << "hey\n";
    return 0;
}