#include <iostream>
using namespace std;
int main() {
    float b, h;
    cout << "Enter base and height: ";
    cin >> b >> h;
    cout << "Area = " << 0.5 * b * h;
    return 0;
}