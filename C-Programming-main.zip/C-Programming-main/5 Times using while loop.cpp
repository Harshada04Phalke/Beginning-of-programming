#include <iostream>
using namespace std;

int main() {
    int i = 0;
    while (i < 5) {
        cout << "hi ";
        i++;
    }
    return 0;
}