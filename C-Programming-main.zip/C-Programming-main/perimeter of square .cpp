#include <iostream>
using namespace std;
int main() {
    float s;
    cout << "Enter side of square: ";
    cin >> s;
    cout << "Perimeter = " << 4 * s;
    return 0;
}