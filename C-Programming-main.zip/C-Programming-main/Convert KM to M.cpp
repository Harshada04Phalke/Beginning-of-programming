#include <iostream>
using namespace std;
int main() {
    float km;
    cout << "Enter distance in km: ";
    cin >> km;
    cout << "Meters = " << km * 1000;
    return 0;
}