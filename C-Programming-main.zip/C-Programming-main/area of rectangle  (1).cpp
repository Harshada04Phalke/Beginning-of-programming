#include <iostream>
using namespace std;

int main() {
    int l, w;
    cout << "Enter length and width: ";
    cin >> l >> w;
    cout << "Area = " << l*w << endl;
    return 0;
}