// save as hi.cpp
#include <iostream>

int main() {
    std::cout << "hello\n";
    return 0;
}