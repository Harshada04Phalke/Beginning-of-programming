#include <iostream>
using namespace std;

int main() {
    cout << "hi hi hi";
    return 0;
}