#include <stdio.h>
int main() {
    int n;
    printf("Enter number: ");
    scanf("%d", &n);
    printf("Cube = %d\n", n*n*n);
    return 0;
}