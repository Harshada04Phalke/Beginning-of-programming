#include <iostream>
using namespace std;
int main() {
    float a, b, c;
    cout << "Enter three numbers: ";
    cin >> a >> b >> c;
    cout << "Average = " << (a + b + c) / 3;
    return 0;
}