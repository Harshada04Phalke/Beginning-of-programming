#include <iostream>
using namespace std;

void greet() {
    cout << "hi";
}

int main() {
    greet();
    return 0;
}